export * from './common';
import * as commonStyle from './variable';
import $api from './api';
import modal from './modal';
import ymodal from './ymodal';
import regex from './regex';
export { commonStyle, modal, ymodal, $api, regex };
